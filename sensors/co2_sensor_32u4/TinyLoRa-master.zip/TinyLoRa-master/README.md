# Adafruit TinyLoRa Library [![Build Status](https://github.com/adafruit/TinyLoRa/workflows/Arduino%20Library%20CI/badge.svg)](https://github.com/adafruit/TinyLoRa/actions)[![Documentation](https://github.com/adafruit/ci-arduino/blob/master/assets/doxygen_badge.svg)](http://adafruit.github.io/TinyLoRa/html/index.html)

Library for communicating with [The Things Network](https://www.thethingsnetwork.org/) using a Hope RF RFM95/96/97/98(W) LoRa Transceiver Module.

## Documentation/Links

The Doxygen documentation is automatically generated from the source files
in this repository, and documents the API exposed by this driver. For
practical details on how to connect and use this sensor, consult the Learning
Guide.

- [Adafruit Learning Guide](https://learn.adafruit.com/the-things-network-for-feather)
  (Installation details for Feather 32u4/Feather M0.)
- [API Documentation](https://adafruit.github.io/TinyLoRa/) (automatically generated via doxygen from source)
- [Adafruit Feather 32u4 RFM95 LoRa Radio](https://www.adafruit.com/product/3078)
- [Adafruit Feather M0 with RFM95 LoRa Radio](https://www.adafruit.com/product/3178)

## License

This library was written by [ClemensRiederer](https://github.com/ClemensRiederer/TinyLoRa-BME280). We've modified it to support channel/datarate selections and made small changes so it works with the Adafruit Feather 32u4 LoRa and the Adafruit Feather M0 LoRa. We've added examples for using this library to transmit sensor data over a single channel or multiple channels to The Things Network.

This open source code is licensed under the LGPL license (see [LICENSE](LICENSE)
for details).
